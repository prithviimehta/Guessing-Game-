import { View, Text, Dimensions } from "react-native";

const GameOverScreen = () => {
  return (
    <View>
      <Text>GameOverScreen</Text>
    </View>
  );
};

export default GameOverScreen;
